Training utils
=========================

Core APIs
~~~~~~~~~~~~~~~~~

.. automodule::  verl.utils.metric
   :members: reduce_metrics
